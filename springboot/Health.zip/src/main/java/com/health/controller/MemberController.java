package com.health.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.health.member.MemberService;
import com.health.member.MemberVO;

@Controller
public class MemberController {
	@Autowired
	private MemberService service;
	
	@GetMapping("/insertMember.do")
	String memberInsert(MemberVO vo) {
		
		
		service.memberInsert(vo);
		return "/index.do";
		
	}
	@GetMapping("/memberList.do")
	String memberList(Model model) {
		
		model.addAttribute("li", service.memberList());
		return "/member/memberList.html";
		
	}
}
