package com.health.member;

import lombok.Data;

@Data
public class MemberVO {
	private int memberidx;
	private String id;
	private String password;
	private String role;
	private String name;
	
}
